package set.starl.injection.mixins.cull;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1533;
import net.minecraft.class_1657;
import net.minecraft.class_1668;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4076;
import net.minecraft.class_4604;
import net.minecraft.class_8836;
import net.minecraft.class_897;
import net.minecraft.class_9817;
import org.joml.FrustumIntersection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starl.LomkaCore;
import set.starl.injection.access.EntityCullingAccessor;
import set.starl.injection.access.FrustumIntersectionAccess;
import set.starl.util.SectionVisibilityCache;

@Mixin(class_897.class)
public abstract class EntityRendererCullingMixin {
    @Unique
    private static final boolean LOMKA$FRUSTUM_CULL_ALL = LomkaCore.CONFIG.culling.enable && LomkaCore.CONFIG.culling.frustumCullAll;
	@Unique
	private static final int LOMKA$FRUSTUM_HYSTERESIS_TICKS = LomkaCore.CONFIG.culling.frustumHysteresisTicks;
	@Unique
	private static final boolean LOMKA$FRUSTUM_HYSTERESIS_ENABLE = LOMKA$FRUSTUM_HYSTERESIS_TICKS > 0;
	@Unique
	private static final boolean LOMKA$SECTION_OCCLUSION_CULL = LomkaCore.CONFIG.culling.enable && LomkaCore.CONFIG.culling.sectionOcclusionCull;
    @Unique
    private static final double LOMKA$SECTION_OCCLUSION_MIN_DIST_SQ = 32.0 * 32.0;

	@Shadow
	protected abstract class_238 getBoundingBoxForCulling(class_1297 entity);

    // === Frustum cull all with hysteresis, motion hash, camera hash, section occlusion ===
    @Inject(method = "shouldRender", at = @At("RETURN"), cancellable = true)
	private void lomka$frustumCullAll(class_1297 entity, class_4604 culler, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
		if (!LOMKA$FRUSTUM_CULL_ALL) return;
		if (!cir.getReturnValue()) return;
		if (entity.method_5807()) return;

		if (!(entity instanceof EntityCullingAccessor accessor)) return;

		class_310 mc = class_310.method_1551();
		int tick = mc.field_1687 != null ? (int) mc.field_1687.method_8510() : Integer.MIN_VALUE;

        // Compute camera hash (15-bit) for hysteresis — detect camera movement
        int camHash15 = LomkaCore.MathHelper.hash3(
            class_4076.method_42615(camX * 2.0),
            class_4076.method_42615(camY * 2.0),
            class_4076.method_42615(camZ * 2.0)
        ) & 32767;

		// Compute motion hash — detect entity movement/rotation
		int motionHash = lomka$computeMotionHash(entity);

		// Hysteresis: skip recheck if within interval and camera/motion unchanged
		if (LOMKA$FRUSTUM_HYSTERESIS_ENABLE && tick != Integer.MIN_VALUE) {
			int lastTick = accessor.lomka$getLastRenderTick();
			int interval = lomka$adjustIntervalByType(entity, LOMKA$FRUSTUM_HYSTERESIS_TICKS + 1);
			if (tick - lastTick < interval
				&& camHash15 == accessor.lomka$getLastRenderCamHash()
				&& motionHash == accessor.lomka$getLastRenderMotionHash()) {
				if (!accessor.lomka$isRenderVisible()) {
					cir.setReturnValue(Boolean.FALSE);
				}
				return;
			}
		}

        // Distance-based fast rejects for non-player entities
        if (mc.field_1687 != null && !(entity instanceof class_1657)) {
            double distSq = LomkaCore.MathHelper.distSq(entity.method_23317(), entity.method_23318(), entity.method_23321(), camX, camY, camZ);

            // Section occlusion cull — skip entities in invisible sections
            if (LOMKA$SECTION_OCCLUSION_CULL && distSq >= LOMKA$SECTION_OCCLUSION_MIN_DIST_SQ) {
                if (!(entity instanceof class_9817 leashable) || leashable.method_60952() == null) {
                    SectionVisibilityCache.ensureCameraCache((long) tick);
                    int esx = class_4076.method_42615(entity.method_23317());
                    int esz = class_4076.method_42615(entity.method_23321());
                    int edx = esx - SectionVisibilityCache.getCamChunkX();
                    int edz = esz - SectionVisibilityCache.getCamChunkZ();
                    if (edx * edx + edz * edz > 16) {
                        long cellKey = class_4076.method_18685(
                            esx,
                            class_4076.method_42615(entity.method_23318()),
                            esz
                        );
                        if (!SectionVisibilityCache.isSectionVisible(cellKey)) {
                            lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, false);
                            cir.setReturnValue(Boolean.FALSE);
                            return;
                        }
                    }
                }
            }
        }
		// Frustum test — reuse AABB, avoid allocation
        class_238 baseBox = this.getBoundingBoxForCulling(entity);
        if (baseBox.method_1013() || baseBox.method_995() == 0.0) {
            double ex = entity.method_23317();
            double ey = entity.method_23318();
            double ez = entity.method_23321();
            baseBox = new class_238(ex - 2.0, ey - 2.0, ez - 2.0, ex + 2.0, ey + 2.0, ez + 2.0);
        }
        // Primary: FrustumIntersection directly — zero allocation, faster than vanilla AABB test
        boolean visible;
        if (culler instanceof FrustumIntersectionAccess fia) {
            FrustumIntersection fi = fia.lomka$getIntersection();
            if (fi != null) {
                float fMinX = (float) (baseBox.field_1323 - 0.5 - camX);
                float fMinY = (float) (baseBox.field_1322 - 0.5 - camY);
                float fMinZ = (float) (baseBox.field_1321 - 0.5 - camZ);
                float fMaxX = (float) (baseBox.field_1320 + 0.5 - camX);
                float fMaxY = (float) (baseBox.field_1325 + 0.5 - camY);
                float fMaxZ = (float) (baseBox.field_1324 + 0.5 - camZ);
                visible = fi.intersectAab(fMinX, fMinY, fMinZ, fMaxX, fMaxY, fMaxZ) != FrustumIntersection.OUTSIDE;
            } else {
                visible = culler.method_23093(baseBox);
            }
        } else {
            visible = culler.method_23093(baseBox);
        }

		if (visible) {
			lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, true);
		} else {
			// Don't cull leashed entities
			if (entity instanceof class_9817 leashable && leashable.method_60952() != null) {
				return;
			}
			lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, false);
			cir.setReturnValue(Boolean.FALSE);
		}
	}

	@Unique
	private static void lomka$recordFrustumDecision(EntityCullingAccessor accessor, int tick, int camHash15, int motionHash, boolean visible) {
		accessor.lomka$setLastRenderTick(tick);
		accessor.lomka$setLastRenderCamHash(camHash15);
		accessor.lomka$setLastRenderMotionHash(motionHash);
		accessor.lomka$setRenderVisible(visible);
	}

    @Unique
    private static int lomka$adjustIntervalByType(class_1297 entity, int interval) {
        if (interval <= 1) return interval;
        // Fast path: most entities use default interval
        if (entity instanceof class_1533) return interval * 2;
        if (entity instanceof class_1668) return Math.max(1, interval / 4);
        if (entity instanceof class_8836 || entity instanceof class_1309) return Math.max(1, interval / 2);
        return interval;
    }

	@Unique
	private static int lomka$computeMotionHash(class_1297 entity) {
		int qx = class_4076.method_42615(entity.method_23317() * 2.0);
		int qy = class_4076.method_42615(entity.method_23318() * 2.0);
		int qz = class_4076.method_42615(entity.method_23321() * 2.0);
		int h = 1;
		h = 31 * h + qx;
		h = 31 * h + qy;
		h = 31 * h + qz;

		boolean isVehicle = entity instanceof class_8836;
		boolean includeRot = entity instanceof class_1309 || isVehicle;
		boolean includeVel = entity instanceof class_1668 || isVehicle;

		if (includeRot) {
			int yawQ = Math.round((entity.method_36454() + 180.0f) * 2.0f);
			int pitchQ = Math.round((Math.max(-90.0f, Math.min(90.0f, entity.method_36455())) + 90.0f) * 2.0f);
			h = 31 * h + yawQ;
			h = 31 * h + pitchQ;
		}

		if (includeVel) {
			class_243 v = entity.method_18798();
			int vx = class_4076.method_42615(v.field_1352 * 20.0);
			int vy = class_4076.method_42615(v.field_1351 * 20.0);
			int vz = class_4076.method_42615(v.field_1350 * 20.0);
			h = 31 * h + vx;
			h = 31 * h + vy;
			h = 31 * h + vz;
		}

		return h;
	}
}