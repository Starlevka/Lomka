package set.starl.config;

import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7919;
import org.jspecify.annotations.NonNull;

public final class LomkaConfigScreen extends class_437 {
	private static final class_2561 TITLE = class_2561.method_43471("lomka.config.title");
	private static final int ITEM_HEIGHT = 24;
	
	private final class_437 parent;
	private final LomkaConfig config;
	private ConfigListWidget list;
	
	public static class_437 create(class_437 parent) {
		return new LomkaConfigScreen(parent);
	}
	
	private LomkaConfigScreen(class_437 parent) {
		super(TITLE);
		this.parent = parent;
		this.config = LomkaConfig.get();
	}
	
	@Override
	protected void method_25426() {
		this.list = new ConfigListWidget(field_22787, field_22789, field_22790 - 64, 32);
		
		buildConfigEntries();
		
		this.method_37063(this.list);
		
		this.method_37063(class_4185.method_46430(class_5244.field_24334, button -> {
			saveAndClose();
		}).method_46434(field_22789 / 2 - 100, field_22790 - 28, 200, 20).method_46431());
	}
	
	private void buildConfigEntries() {
		// Shaders section
		this.list.addHeader(class_2561.method_43471("lomka.config.section.shaders"));
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.shaders.program_binary_cache.enable"),
			config.shaders.programBinaryCache.enable, 
			val -> config.shaders.programBinaryCache.enable = val,
			class_2561.method_43471("lomka.config.shaders.program_binary_cache.enable.tooltip")
		);
		
        // Culling section
        this.list.addHeader(class_2561.method_43471("lomka.config.section.culling"));
        this.list.addBooleanOption(
            class_2561.method_43471("lomka.config.culling.enable"),
            config.culling.enable, 
            val -> config.culling.enable = val,
            class_2561.method_43471("lomka.config.culling.enable.tooltip")
        );
        this.list.addBooleanOption(
            class_2561.method_43471("lomka.config.culling.frustum_cull_all"),
            config.culling.frustumCullAll, 
            val -> config.culling.frustumCullAll = val,
            class_2561.method_43471("lomka.config.culling.frustum_cull_all.tooltip")
        );
        this.list.addBooleanOption(
            class_2561.method_43471("lomka.config.culling.section_occlusion_cull"),
            config.culling.sectionOcclusionCull, 
            val -> config.culling.sectionOcclusionCull = val,
            class_2561.method_43471("lomka.config.culling.section_occlusion_cull.tooltip")
        );
        this.list.addBooleanOption(
            class_2561.method_43471("lomka.config.culling.block_entity_culling"),
            config.culling.blockEntityCulling, 
            val -> config.culling.blockEntityCulling = val,
            class_2561.method_43471("lomka.config.culling.block_entity_culling.tooltip")
        );
        this.list.addBooleanOption(
            class_2561.method_43471("lomka.config.culling.smart_leaves_culling"),
            config.culling.smartLeavesCulling,
            val -> config.culling.smartLeavesCulling = val,
            class_2561.method_43471("lomka.config.culling.smart_leaves_culling.tooltip")
        );
        // Textures section
		this.list.addHeader(class_2561.method_43471("lomka.config.section.textures"));
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.textures.decode.off_thread"),
			config.textures.decode.offThread, 
			val -> config.textures.decode.offThread = val,
			class_2561.method_43471("lomka.config.textures.decode.off_thread.tooltip")
		);
		
		// Chunks section
		this.list.addHeader(class_2561.method_43471("lomka.config.section.chunks"));
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.chunks.silence_ignore_out_of_range_log"),
			config.chunks.silenceIgnoreOutOfRangeLog, 
			val -> config.chunks.silenceIgnoreOutOfRangeLog = val,
			class_2561.method_43471("lomka.config.chunks.silence_ignore_out_of_range_log.tooltip")
		);
		
		// NBT section
		this.list.addHeader(class_2561.method_43471("lomka.config.section.nbt"));
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.nbt.cache.read_compressed_path"),
			config.nbt.cache.readCompressedPath, 
			val -> config.nbt.cache.readCompressedPath = val,
			class_2561.method_43471("lomka.config.nbt.cache.read_compressed_path.tooltip")
		);
		
		// Network section
		this.list.addHeader(class_2561.method_43471("lomka.config.section.network"));
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.network.compression_decoder.direct_input_reuse"),
			config.network.compressionDecoder.directInputReuse, 
			val -> config.network.compressionDecoder.directInputReuse = val,
			class_2561.method_43471("lomka.config.network.compression_decoder.direct_input_reuse.tooltip")
		);
		
		// Render section
		this.list.addHeader(class_2561.method_43471("lomka.config.section.render"));
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.render.opengl_debug_disable"),
			config.render.openglDebugDisable, 
			val -> config.render.openglDebugDisable = val,
			class_2561.method_43471("lomka.config.render.opengl_debug_disable.tooltip")
		);
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.render.translucency_resort_throttle"),
			config.render.translucencyResortThrottle, 
			val -> config.render.translucencyResortThrottle = val,
			class_2561.method_43471("lomka.config.render.translucency_resort_throttle.tooltip")
        );
        // Java section
		this.list.addHeader(class_2561.method_43471("lomka.config.section.java"));
		this.list.addBooleanOption(
			class_2561.method_43471("lomka.config.java.java25_optimizations"),
			config.java.java25Optimizations, 
			val -> config.java.java25Optimizations = val,
			class_2561.method_43471("lomka.config.java.java25_optimizations.tooltip")
		);
	}
	
	private void saveAndClose() {
		LomkaConfig.save();
		this.field_22787.method_1507(this.parent);
	}
	
	@Override
	public void method_25419() {
		this.field_22787.method_1507(this.parent);
	}
	
	private final class ConfigListWidget extends class_4265 {
		public ConfigListWidget(class_310 minecraft, int width, int height, int y) {
			super(minecraft, width, height, y, ITEM_HEIGHT);
		}
		
		public void addHeader(class_2561 text) {
			this.method_25321(new HeaderEntry(text));
		}
		
		public void addBooleanOption(class_2561 name, boolean value, Consumer<Boolean> setter, class_2561 tooltip) {
			this.method_25321(new BooleanOptionEntry(name, value, setter, tooltip));
		}
		
		@Override
		public int method_25322() {
			return Math.min(400, this.field_22758 - 50);
		}
	}
	
	private final class HeaderEntry extends class_4265.class_4266 {
		private final class_2561 text;
		private final int color;
		
		HeaderEntry(class_2561 text) {
			this(text, 0xFFAAAAAA);
		}
		
		HeaderEntry(class_2561 text, int color) {
			this.text = text;
			this.color = color;
		}
		
		@Override
		public void method_25343(@NonNull class_332 graphics, int mouseX, int mouseY, boolean hovered, float partialTick) {
			graphics.method_27534(class_310.method_1551().field_1772, this.text, LomkaConfigScreen.this.field_22789 / 2, this.method_73382() + 4, this.color);
		}
		
		@Override
		public List<? extends class_339> method_25396() {
			return List.of();
		}
		
		@Override
		public List<? extends class_339> method_37025() {
			return List.of();
		}
	}
	
	private final class BooleanOptionEntry extends class_4265.class_4266 {
		private final class_2561 name;
		private final class_2561 tooltip;
		private boolean value;
		private final Consumer<Boolean> setter;
		private final class_4185 toggleButton;
		
		BooleanOptionEntry(class_2561 name, boolean value, Consumer<Boolean> setter, class_2561 tooltip) {
			this.name = name;
			this.value = value;
			this.setter = setter;
			this.tooltip = tooltip;
			this.toggleButton = class_4185.method_46430(getValueText(), button -> {
				BooleanOptionEntry.this.value = !BooleanOptionEntry.this.value;
				BooleanOptionEntry.this.setter.accept(BooleanOptionEntry.this.value);
				button.method_25355(getValueText());
			}).method_46434(0, 0, 75, 20).method_46431();
			
			if (this.tooltip != null && !this.tooltip.getString().isEmpty()) {
				this.toggleButton.method_47400(class_7919.method_47407(this.tooltip));
			}
		}
		
		@Override
		public void method_25343(@NonNull class_332 graphics, int mouseX, int mouseY, boolean hovered, float partialTick) {
			graphics.method_27535(class_310.method_1551().field_1772, this.name, this.method_73380(), this.method_73382() + 6, 0xFFFFFFFF);
			this.toggleButton.method_48229(this.method_73380() + this.method_73387() - 80, this.method_73382());
			this.toggleButton.method_25394(graphics, mouseX, mouseY, partialTick);
		}
		
		@Override
		public List<? extends class_339> method_25396() {
			return List.of(this.toggleButton);
		}
		
		@Override
		public List<? extends class_339> method_37025() {
			return List.of(this.toggleButton);
		}
		
		private class_2561 getValueText() {
			return this.value 
				? class_2561.method_43471("lomka.config.on")
				: class_2561.method_43471("lomka.config.off");
		}
	}
}