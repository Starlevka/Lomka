package set.starl.util;

import net.minecraft.class_2487;

public record NbtCacheEntry(class_2487 tag, long mtime, long size) {}
