package set.starl.util;

import net.minecraft.class_4604;

public record CullingContext(
	long gameTime,
	double camX,
	double camY,
	double camZ,
	int camChunkX,
	int camChunkZ,
	class_4604 frustum
) {
}
