package set.starl.injection.mixins.accessors;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import set.starl.injection.access.LevelRendererAccess;

import java.util.SortedSet;
import net.minecraft.class_3191;
import net.minecraft.class_761;
import net.minecraft.class_846;

@Mixin(class_761.class)
public abstract class LevelRendererAccessor implements LevelRendererAccess {
	@Shadow
	private ObjectArrayList<class_846.class_851> visibleSections;

	@Shadow
	private Long2ObjectMap<SortedSet<class_3191>> destructionProgress;

	@Shadow
	private net.minecraft.class_4604 capturedFrustum;

	@Override
	public ObjectArrayList<class_846.class_851> lomka$getVisibleSections() {
		return this.visibleSections;
	}

	@Override
	public Long2ObjectMap<SortedSet<class_3191>> lomka$getDestructionProgress() {
		return this.destructionProgress;
	}

	@Override
	public net.minecraft.class_4604 lomka$getLastCullFrustum() {
		return this.capturedFrustum;
	}

	@Override
	public net.minecraft.class_4604 lomka$getLastAppliedFrustum() {
		return this.capturedFrustum;
	}
}
