package set.starl.injection.mixins.texture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import net.minecraft.class_7677;
import net.minecraft.class_7764;
import net.minecraft.class_7766;
import net.minecraft.class_8684;
import java.util.Set;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import set.starl.LomkaCore;

@Mixin(class_7766.class)
public class SpriteResourceLoaderOffThreadMixin {
	@Redirect(
		method = "loadAndStitch",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/texture/atlas/SpriteResourceLoader;create(Ljava/util/Set;)Lnet/minecraft/client/renderer/texture/atlas/SpriteResourceLoader;"
		)
	)
    private class_8684 lomka$wrapSpriteLoader(final Set<class_7677<?>> additionalMetadataSections) {
        class_8684 original = class_8684.create(additionalMetadataSections);
        if (!LomkaCore.TEXTURE_DECODE_OFF_THREAD) {
            return original;
        }
        class_8684 wrapped = (spriteLocation, resource) -> {
            if (Boolean.TRUE.equals(LomkaCore.IN_TEXTURE_DECODE.get())) {
                return original.loadSprite(spriteLocation, resource);
            }
            LomkaCore.TEXTURE_DECODE_GUARD.acquireUninterruptibly();
            LomkaCore.IN_TEXTURE_DECODE.set(Boolean.TRUE);

            class_7764 result;
            try {
                CompletableFuture<class_7764> future = CompletableFuture.supplyAsync(() -> original.loadSprite(spriteLocation, resource), LomkaCore.TEXTURE_DECODE_EXECUTOR);
                try {
                    result = future.join();
                } catch (CompletionException e) {
                    Throwable cause = e.getCause();
                    if (cause instanceof RuntimeException re) {
                        throw re;
                    }
                    if (cause instanceof Error err) {
                        throw err;
                    }
                    throw e;
                }
            } finally {
                LomkaCore.IN_TEXTURE_DECODE.set(Boolean.FALSE);
                LomkaCore.TEXTURE_DECODE_GUARD.release();
            }

            return result;
        };
        return wrapped;
    }
}