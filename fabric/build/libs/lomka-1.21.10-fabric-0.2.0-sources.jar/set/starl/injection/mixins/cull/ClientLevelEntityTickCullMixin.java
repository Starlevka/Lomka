package set.starl.injection.mixins.cull;

import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1534;
import net.minecraft.class_4076;
import net.minecraft.class_5915;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starl.LomkaCore;
import set.starl.util.SectionVisibilityCache;
@Mixin(class_638.class)
public abstract class ClientLevelEntityTickCullMixin {
	@Unique
	private static final boolean LOMKA$ENABLE = LomkaCore.CONFIG.entities.enable && LomkaCore.CONFIG.entities.clientTickCull;
	@Unique
	private static final double LOMKA$MIN_DIST_SQ;
	@Unique
	private static final int LOMKA$MIN_CHUNK_DISTANCE = 4;
	@Unique
    private static final int LOMKA$INTERVAL_TICKS = 20;
	@Unique
	private static final boolean LOMKA$SECTION_OCCLUSION_CULL = LomkaCore.CONFIG.culling.enable && LomkaCore.CONFIG.culling.sectionOcclusionCull;
	@Unique
    private static final boolean LOMKA$INCLUDE_DISPLAY = LomkaCore.CONFIG.entities.clientTickCullIncludeDisplay;

    @Inject(method = "tickNonPassenger", at = @At("HEAD"), cancellable = true)
    private void lomka$throttleTickNonPassenger(class_1297 entity, CallbackInfo ci) {
		if (!LOMKA$ENABLE) return;
		if (LOMKA$MIN_DIST_SQ <= 0.0) return;
		if (!lomka$isCandidate(entity)) return;

        // Cache level identity — avoid repeated cast
        class_638 level = (class_638) (Object) this;
        SectionVisibilityCache.checkLevelChange(System.identityHashCode(level));

		// Warmup: let entities tick normally for first few ticks after spawn
		if (entity.field_6012 < 5) return;

		// Don't throttle entities with passengers (vehicles carrying players)
		if (!entity.method_5685().isEmpty()) return;

		long gameTime = level.method_8510();
		if (!SectionVisibilityCache.ensureCameraCache(gameTime)) return;

        // Distance check — chunk distance first (cheap), then exact distance² (expensive)
        int ecx = class_4076.method_18675(entity.method_31477());
        int ecz = class_4076.method_18675(entity.method_31479());
        int dx = Math.abs(ecx - SectionVisibilityCache.getCamChunkX());
        int dz = Math.abs(ecz - SectionVisibilityCache.getCamChunkZ());
        double dist2;
        if (dx < LOMKA$MIN_CHUNK_DISTANCE && dz < LOMKA$MIN_CHUNK_DISTANCE) {
            dist2 = LomkaCore.MathHelper.distSq(
                entity.method_23317(), entity.method_23318(), entity.method_23321(),
                SectionVisibilityCache.getCamX(), SectionVisibilityCache.getCamY(), SectionVisibilityCache.getCamZ()
            );
            if (dist2 < LOMKA$MIN_DIST_SQ) return;
        } else {
            dist2 = LomkaCore.MathHelper.distSq(
                entity.method_23317(), entity.method_23318(), entity.method_23321(),
                SectionVisibilityCache.getCamX(), SectionVisibilityCache.getCamY(), SectionVisibilityCache.getCamZ()
            );
            if (dist2 < LOMKA$MIN_DIST_SQ) return;
        }

        // Section occlusion cull — skip entities in invisible sections
        if (LOMKA$SECTION_OCCLUSION_CULL && !(entity instanceof net.minecraft.class_1657)) {
            if (dist2 < 0.0 || dist2 >= LOMKA$MIN_DIST_SQ) {
                long cellKey = class_4076.method_18685(ecx,
                    class_4076.method_18675(entity.method_31478()), ecz);
                if (!SectionVisibilityCache.isSectionVisible(cellKey)) {
                    entity.method_22862();
                    ++entity.field_6012;
                    ci.cancel();
                    return;
                }
            }
        }
		// Phase-based throttle: tick every N ticks based on entity ID
        long phase = gameTime + (long) entity.method_5628();
        if (phase % LOMKA$INTERVAL_TICKS != 0L) {
            entity.method_22862();
            ++entity.field_6012;
            ci.cancel();
        }
	}

	@Unique
	private static boolean lomka$isCandidate(class_1297 entity) {
		return entity instanceof class_1533
			|| entity instanceof class_1534
			|| entity instanceof class_5915
			|| (LOMKA$INCLUDE_DISPLAY && entity instanceof net.minecraft.class_8113);
	}

    static {
		double minDist = LomkaCore.CONFIG.entities.clientTickCullMinDistance;
		LOMKA$MIN_DIST_SQ = minDist <= 0.0 ? -1.0 : minDist * minDist;
	}
}