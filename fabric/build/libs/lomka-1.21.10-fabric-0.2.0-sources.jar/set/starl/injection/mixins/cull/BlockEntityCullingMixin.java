package set.starl.injection.mixins.cull;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.class_11658;
import net.minecraft.class_11683;
import net.minecraft.class_11954;
import net.minecraft.class_2586;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_824;
import org.joml.FrustumIntersection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import set.starl.injection.access.FrustumIntersectionAccess;
import set.starl.injection.access.LevelRendererAccess;
@Mixin(class_761.class)
public abstract class BlockEntityCullingMixin {

    @Unique
    private static final boolean LOMKA$BLOCK_ENTITY_CULLING = set.starl.LomkaCore.CONFIG.culling.blockEntityCulling;

    @WrapOperation(
        method = "extractVisibleBlockEntities",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/blockentity/BlockEntityRenderDispatcher;tryExtractRenderState(Lnet/minecraft/world/level/block/entity/BlockEntity;FLnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)Lnet/minecraft/client/renderer/blockentity/state/BlockEntityRenderState;",
            ordinal = 1
        )
    )
    private class_11954 lomka$wrapGlobalBlockEntityExtraction(class_824 instance, class_2586 blockEntity, float partialTicks, class_11683.class_11792 breakProgress, Operation<class_11954> original, class_4184 camera, float deltaPartialTick, class_11658 levelRenderState) {
        if (!LOMKA$BLOCK_ENTITY_CULLING) {
            return original.call(instance, blockEntity, partialTicks, breakProgress);
        }

        // Frustum check via FrustumIntersection directly — zero AABB allocation
        class_4604 frustum = ((LevelRendererAccess) this).lomka$getLastAppliedFrustum();
        if (frustum != null) {
            FrustumIntersection fi = ((FrustumIntersectionAccess) frustum).lomka$getIntersection();
            if (fi != null) {
                int x = blockEntity.method_11016().method_10263();
                int y = blockEntity.method_11016().method_10264();
                int z = blockEntity.method_11016().method_10260();
                if (fi.intersectAab((float)x, (float)y, (float)z, (float)(x + 1), (float)(y + 1), (float)(z + 1)) == FrustumIntersection.OUTSIDE) {
                    return null;
                }
            }
        }

        return original.call(instance, blockEntity, partialTicks, breakProgress);
    }

}
