package set.starl.injection.mixins.cull;

import net.minecraft.class_2350;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starl.LomkaCore;

@Mixin(class_4970.class)
public class SmartLeavesCullingMixin {
	@Inject(method = "skipRendering(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z", at = @At("HEAD"), cancellable = true)
	private void lomka$smartCull(class_2680 state, class_2680 neighbor, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        if (!LomkaCore.CONFIG.culling.smartLeavesCulling) {
			return;
		}
		if (!(state.method_26204() instanceof class_2397)) {
			return;
		}
		if (!(neighbor.method_26204() instanceof class_2397)) {
			return;
		}
		// Don't cull if waterlogged state differs (visible water gap)
		if (state.method_28498(class_2741.field_12508)
			&& neighbor.method_28498(class_2741.field_12508)
			&& state.method_11654(class_2741.field_12508) != neighbor.method_11654(class_2741.field_12508)) {
			return;
		}
		cir.setReturnValue(true);
	}
}