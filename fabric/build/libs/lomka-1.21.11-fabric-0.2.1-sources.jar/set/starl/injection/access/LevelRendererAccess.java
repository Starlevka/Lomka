package set.starl.injection.access;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jspecify.annotations.Nullable;

import java.util.SortedSet;
import net.minecraft.class_3191;
import net.minecraft.class_4604;
import net.minecraft.class_846;

public interface LevelRendererAccess {
	@Nullable
	class_4604 lomka$getLastCullFrustum();

	@Nullable
	class_4604 lomka$getLastAppliedFrustum();

	ObjectArrayList<class_846.class_851> lomka$getVisibleSections();

	Long2ObjectMap<SortedSet<class_3191>> lomka$getDestructionProgress();

}

