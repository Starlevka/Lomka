package set.starl.injection.mixins.accessors;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starl.injection.access.LevelRendererAccess;

import java.util.SortedSet;
import net.minecraft.class_3191;
import net.minecraft.class_4604;
import net.minecraft.class_761;
import net.minecraft.class_846;

@Mixin(class_761.class)
public abstract class LevelRendererAccessor implements LevelRendererAccess {
	@Shadow
	private ObjectArrayList<class_846.class_851> visibleSections;

	@Shadow
	private Long2ObjectMap<SortedSet<class_3191>> destructionProgress;

	@Shadow
	private @Nullable class_4604 capturedFrustum;

	/**
	 * Stores the real frustum used for culling. Unlike {@code capturedFrustum}
	 * (which is debug-only and null in normal gameplay), this field is populated
	 * every time {@code applyFrustum} runs.
	 */
	@Unique
	private @Nullable class_4604 lomka$lastAppliedFrustum;

	/**
	 * Capture the frustum that is actually used for section culling.
	 * In vanilla, {@code applyFrustum(Frustum)} is called from {@code cullTerrain}
	 * with the offset frustum. This is the real frustum used for visibility.
	 */
	@Inject(method = "applyFrustum", at = @At("HEAD"))
	private void lomka$captureAppliedFrustum(class_4604 frustum, CallbackInfo ci) {
		this.lomka$lastAppliedFrustum = frustum;
	}

	@Override
	public ObjectArrayList<class_846.class_851> lomka$getVisibleSections() {
		return this.visibleSections;
	}

	@Override
	public Long2ObjectMap<SortedSet<class_3191>> lomka$getDestructionProgress() {
		return this.destructionProgress;
	}

	@Override
	public @Nullable class_4604 lomka$getLastCullFrustum() {
		// Return the real frustum if available, fall back to debug frustum
		class_4604 applied = this.lomka$lastAppliedFrustum;
		return applied != null ? applied : this.capturedFrustum;
	}

	@Override
	public @Nullable class_4604 lomka$getLastAppliedFrustum() {
		class_4604 applied = this.lomka$lastAppliedFrustum;
		return applied != null ? applied : this.capturedFrustum;
	}
}
