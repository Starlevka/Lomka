package set.starl.injection.mixins.texture;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import net.minecraft.class_1011;
import net.minecraft.class_7958;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import set.starl.Lomka;

@Mixin(class_7958.class)
public class LazyLoadedImageOffThreadMixin {
	@Redirect(
		method = "get",
		at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/platform/NativeImage;read(Ljava/io/InputStream;)Lcom/mojang/blaze3d/platform/NativeImage;"
		)
	)
	private class_1011 lomka$readOffThread(final InputStream inputStream) throws IOException {
		final InputStream buffered = inputStream instanceof BufferedInputStream
			? inputStream : new BufferedInputStream(inputStream, 8192);
		if (!Lomka.TEXTURE_DECODE_OFF_THREAD) {
			return class_1011.method_4309(buffered);
		}
		if (Boolean.TRUE.equals(Lomka.IN_TEXTURE_DECODE.get())) {
			return class_1011.method_4309(buffered);
		}
		Lomka.TEXTURE_DECODE_GUARD.acquireUninterruptibly();
		Lomka.IN_TEXTURE_DECODE.set(Boolean.TRUE);
		try {
			CompletableFuture<class_1011> future = CompletableFuture.supplyAsync(() -> {
				try {
					return class_1011.method_4309(buffered);
				} catch (IOException e) {
					throw new CompletionException(e);
				}
			}, Lomka.TEXTURE_DECODE_EXECUTOR);
			try {
				return future.join();
			} catch (CompletionException e) {
				Throwable cause = e.getCause();
				if (cause instanceof IOException io) {
					throw io;
				}
				if (cause instanceof RuntimeException re) {
					throw re;
				}
				throw e;
			}
		} finally {
			Lomka.IN_TEXTURE_DECODE.set(Boolean.FALSE);
			Lomka.TEXTURE_DECODE_GUARD.release();
		}
	}
}
