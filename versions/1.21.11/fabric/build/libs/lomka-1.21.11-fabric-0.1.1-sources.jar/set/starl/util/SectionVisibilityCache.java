package set.starl.util;

import it.unimi.dsi.fastutil.longs.Long2ByteOpenHashMap;
import net.minecraft.class_238;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4076;
import net.minecraft.class_4604;
import set.starl.injection.access.LevelRendererAccess;

public class SectionVisibilityCache {
	// Use a larger initial capacity to avoid rehashing
	private static final Long2ByteOpenHashMap CACHE = new Long2ByteOpenHashMap(4096);
	private static int lastLevelId = Integer.MIN_VALUE;
	private static long lastGameTime = -1L;
	private static double camX, camY, camZ;
	private static int camChunkX, camChunkZ;
	private static class_4604 currentFrustum;
	// Track if we've already cached for this camera position
	private static boolean cacheValid = false;

	static {
		CACHE.defaultReturnValue((byte)-1);
	}

	public static void checkLevelChange(int levelId) {
		if (levelId != lastLevelId) {
			lastLevelId = levelId;
			// Clear less frequently - only on dimension change
			if (!CACHE.isEmpty()) {
				CACHE.clear();
			}
			cacheValid = false;
		}
	}

	public static boolean ensureCameraCache(long gameTime) {
		if (gameTime == lastGameTime && cacheValid && currentFrustum != null) {
			return true;
		}
		var mc = class_310.method_1551();
		if (mc == null || mc.field_1773 == null) {
			return false;
		}
		var cam = mc.field_1773.method_19418();
		if (!cam.method_19332()) {
			return false;
		}
		var entity = cam.method_19331();
		if (entity == null) {
			return false;
		}

		lastGameTime = gameTime;
		var pos = cam.method_71156();
		camX = pos.field_1352;
		camY = pos.field_1351;
		camZ = pos.field_1350;
		camChunkX = class_3532.method_15357(camX) >> 4;
		camChunkZ = class_3532.method_15357(camZ) >> 4;

		currentFrustum = ((LevelRendererAccess)mc.field_1769).lomka$getLastCullFrustum();
		// Don't clear on every call - only when frustum actually changes
		if (currentFrustum != null) {
			cacheValid = true;
		}
		return currentFrustum != null;
	}

	public static double getCamX() { return camX; }
	public static double getCamY() { return camY; }
	public static double getCamZ() { return camZ; }
	public static int getCamChunkX() { return camChunkX; }
	public static int getCamChunkZ() { return camChunkZ; }

	public static boolean isSectionVisible(long sectionKey) {
		// Fast path: check cache first without allocation
		byte cached = CACHE.get(sectionKey);
		if (cached != -1) {
			return cached != 0;
		}

		if (!cacheValid || currentFrustum == null) {
			return true;
		}

		// Avoid AABB allocation by using direct coordinate check
		int x = class_4076.method_18686(sectionKey) << 4;
		int y = class_4076.method_18689(sectionKey) << 4;
		int z = class_4076.method_18690(sectionKey) << 4;

		boolean visible = currentFrustum.method_23093(new class_238(x, y, z, x + 16, y + 16, z + 16));
		// Only cache if we have room - prevents unbounded growth
		if (CACHE.size() < 8192) {
			CACHE.put(sectionKey, (byte)(visible ? 1 : 0));
		}
		return visible;
	}
}
