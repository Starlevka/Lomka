package set.starl.injection.mixins.render;

import net.minecraft.class_10143;
import net.minecraft.class_238;
import net.minecraft.class_4604;
import net.minecraft.class_846;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.client.renderer.Octree$Leaf")
public class OctreeLeafMixin {
	@Shadow
	@Final
	private class_846.class_851 section;

	@Inject(method = "visitNodes", at = @At("HEAD"), cancellable = true)
	private void lomka$visitNodesFast(
		final class_10143.class_10148 visitor,
		final boolean skipFrustumCheck,
		final class_4604 frustum,
		final int depth,
		final int closeDistance,
		final boolean isClose,
		final CallbackInfo ci
	) {
		class_238 boundingBox = this.section.method_40051();
		if (skipFrustumCheck || frustum.method_23093(boundingBox)) {
			boolean close = isClose;
			if (close) {
				double cameraX = frustum.method_62343();
				double cameraY = frustum.method_62344();
				double cameraZ = frustum.method_62345();
				close = cameraX > boundingBox.field_1323 - (double)closeDistance
					&& cameraX < boundingBox.field_1320 + (double)closeDistance
					&& cameraY > boundingBox.field_1322 - (double)closeDistance
					&& cameraY < boundingBox.field_1325 + (double)closeDistance
					&& cameraZ > boundingBox.field_1321 - (double)closeDistance
					&& cameraZ < boundingBox.field_1324 + (double)closeDistance;
			}

			visitor.visit((class_10143.class_10147)(Object)this, skipFrustumCheck, depth, close);
		}

		ci.cancel();
	}
}
