package set.starl.injection.mixins.cull;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.minecraft.class_10255;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1533;
import net.minecraft.class_1534;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1688;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4076;
import net.minecraft.class_4604;
import net.minecraft.class_8113;
import net.minecraft.class_897;
import net.minecraft.class_9817;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starl.injection.access.FrustumIntersectionAccess;
import set.starl.injection.access.EntityCullingAccessor;
import set.starl.util.SectionVisibilityCache;

@Mixin(class_897.class)
public abstract class EntityRendererCullingMixin {
	@Unique
	private static final boolean LOMKA$CULL_INVISIBLE = set.starl.Lomka.CONFIG.entities.enable && set.starl.Lomka.CONFIG.entities.cullInvisible;

	@Unique
	private static final boolean LOMKA$FRUSTUM_CULL_ALL = set.starl.Lomka.CONFIG.entities.enable && set.starl.Lomka.CONFIG.entities.frustumCullAll;

	@Unique
	private static final class_1304[] LOMKA$EQUIPMENT_SLOTS = class_1304.values();

	@Unique
	private static final int LOMKA$FRUSTUM_HYSTERESIS_TICKS = set.starl.Lomka.CONFIG.entities.frustumHysteresisTicks;

	@Unique
	private static final int LOMKA$FRUSTUM_HYSTERESIS_LEGACY_INTERVAL = LOMKA$FRUSTUM_HYSTERESIS_TICKS > 0 ? (LOMKA$FRUSTUM_HYSTERESIS_TICKS + 1) : 0;

	@Unique
	private static final int LOMKA$FRUSTUM_VISIBLE_RECHECK = LOMKA$FRUSTUM_HYSTERESIS_LEGACY_INTERVAL;

	@Unique
	private static final int LOMKA$FRUSTUM_INVISIBLE_RECHECK = LOMKA$FRUSTUM_HYSTERESIS_LEGACY_INTERVAL;

	@Unique
	private static final boolean LOMKA$FRUSTUM_HYSTERESIS_ENABLE = LOMKA$FRUSTUM_VISIBLE_RECHECK > 1 || LOMKA$FRUSTUM_INVISIBLE_RECHECK > 1;

	@Unique
	private static final int LOMKA$FRUSTUM_HYSTERESIS_MAX_ENTRIES = 16384;

	@Unique
	private static final boolean LOMKA$FRUSTUM_SPHERE_TEST = LOMKA$FRUSTUM_HYSTERESIS_ENABLE;

	@Unique
	private static final float LOMKA$FRUSTUM_SPHERE_MARGIN = 0.5f;

	@Unique
	private static final boolean LOMKA$FRUSTUM_CHEAP_DISTANCE_REJECT = false;

	@Unique
	private static final double LOMKA$FRUSTUM_CHEAP_DISTANCE_MARGIN = 2.0;

	@Unique
	private static final double LOMKA$FRUSTUM_HYSTERESIS_STATIC_MULTIPLIER = 2.0;

	@Unique
	private static final double LOMKA$FRUSTUM_HYSTERESIS_LIVING_MULTIPLIER = 0.5;

	@Unique
	private static final double LOMKA$FRUSTUM_HYSTERESIS_DISPLAY_MULTIPLIER = 4.0;

	@Unique
	private static final double LOMKA$FRUSTUM_HYSTERESIS_PROJECTILE_MULTIPLIER = 0.25;

	@Unique
	private static final double LOMKA$FRUSTUM_HYSTERESIS_VEHICLE_MULTIPLIER = 0.5;

	@Unique
	private static final double LOMKA$SECTION_OCCLUSION_CULL_MIN_DISTANCE = 32.0;

	@Unique
	private static final boolean LOMKA$SECTION_OCCLUSION_CULL = set.starl.Lomka.CONFIG.entities.sectionOcclusionCull;

	@Unique
	private static final double LOMKA$DISPLAY_CULL_DISTANCE = set.starl.Lomka.CONFIG.entities.displayCullDistance;


	@Shadow
	protected abstract class_238 getBoundingBoxForCulling(final class_1297 entity);

	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
	private void lomka$cullInvisible(final class_1297 entity, final class_4604 culler, final double camX, final double camY, final double camZ, final CallbackInfoReturnable<Boolean> cir) {
		if (!LOMKA$CULL_INVISIBLE) {
			return;
		}
		// Short circuit: only check players if invisible
		if (!(entity instanceof class_1657)) {
			if (entity.method_5767() && !entity.method_5851()) {
				class_1657 player = class_310.method_1551().field_1724;
				if (player != null && entity.method_5756(player)) {
					if (entity.method_16914() && entity.method_5807()) {
						return;
					}
					if (lomka$hasVisiblePartsWhenInvisible(entity)) {
						return;
					}
					cir.setReturnValue(Boolean.FALSE);
				}
			}
		}
	}

	@Unique
	private static boolean lomka$hasVisiblePartsWhenInvisible(final class_1297 entity) {
		if (entity instanceof class_1309 living) {
			for (class_1304 slot : LOMKA$EQUIPMENT_SLOTS) {
				if (!living.method_6118(slot).method_7960()) {
					return true;
				}
			}
		}
		if (entity instanceof class_1533 frame) {
			return !frame.method_6940().method_7960();
		}
		return false;
	}

	@Inject(method = "shouldRender", at = @At("RETURN"), cancellable = true)
	private void lomka$frustumCullAll(final class_1297 entity, final class_4604 culler, final double camX, final double camY, final double camZ, final CallbackInfoReturnable<Boolean> cir) {
		if (!LOMKA$FRUSTUM_CULL_ALL || !cir.getReturnValue().booleanValue() || entity.method_5807()) {
			return;
		}

		class_310 mc = class_310.method_1551();
		if (!(entity instanceof EntityCullingAccessor accessor)) {
			return;
		}
		final int tick = mc.field_1687 != null ? (int)mc.field_1687.method_75260() : Integer.MIN_VALUE;
		
		final int camHash15 = (int)((((long)class_3532.method_15357(camX * 2.0)) ^ ((long)class_3532.method_15357(camY * 2.0)) ^ ((long)class_3532.method_15357(camZ * 2.0))) >>> 15) & 0x7FFF;
		final int motionHash = lomka$computeMotionHash(entity);

		if (LOMKA$FRUSTUM_HYSTERESIS_ENABLE && tick != Integer.MIN_VALUE) {
			final int lastTick = accessor.lomka$getLastRenderTick();
			// Multi-tick hysteresis skip: reuse visibility if both camera and entity hashes are stable.
			// camHash15 now uses 0.5 block quantization, and motionHash also uses 0.5 block quantization.
			if (tick - lastTick < lomka$adjustIntervalByType(entity, LOMKA$FRUSTUM_HYSTERESIS_TICKS + 1) &&
				camHash15 == accessor.lomka$getLastRenderCamHash() &&
				motionHash == accessor.lomka$getLastRenderMotionHash()) {
				
				if (!accessor.lomka$isRenderVisible()) {
					cir.setReturnValue(Boolean.FALSE);
				}
				return;
			}
		}

		// Occlusion and Distance
		if (mc.field_1687 != null && !(entity instanceof class_1657)) {
			double ddx = entity.method_23317() - camX;
			double ddy = entity.method_23318() - camY;
			double ddz = entity.method_23321() - camZ;
			double distSq = ddx * ddx + ddy * ddy + ddz * ddz;

			if (entity instanceof net.minecraft.class_6335) {
				lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, false);
				cir.setReturnValue(Boolean.FALSE);
				return;
			}

			if (entity instanceof class_8113 || entity instanceof net.minecraft.class_8150) {
				if (distSq > LOMKA$DISPLAY_CULL_DISTANCE * LOMKA$DISPLAY_CULL_DISTANCE) {
					lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, false);
					cir.setReturnValue(Boolean.FALSE);
					return;
				}
			}

			if (LOMKA$SECTION_OCCLUSION_CULL && (!(entity instanceof class_9817 leashable) || leashable.method_60952() == null)) {
				if (distSq >= LOMKA$SECTION_OCCLUSION_CULL_MIN_DISTANCE * LOMKA$SECTION_OCCLUSION_CULL_MIN_DISTANCE) {
					SectionVisibilityCache.ensureCameraCache(tick);
					// Use blockToSectionCoord for slightly cleaner logic
					final int sx = class_4076.method_42615(entity.method_23317());
					final int sy = class_4076.method_42615(entity.method_23318());
					final int sz = class_4076.method_42615(entity.method_23321());
					if (!SectionVisibilityCache.isSectionVisible(class_4076.method_18685(sx, sy, sz))) {
						lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, false);
						cir.setReturnValue(Boolean.FALSE);
						return;
					}
				}
			}
		}

		class_238 baseBox = this.getBoundingBoxForCulling(entity);
		if (baseBox.method_1013() || baseBox.method_995() == 0.0) {
			baseBox = new class_238(entity.method_23317() - 2.0, entity.method_23318() - 2.0, entity.method_23321() - 2.0, entity.method_23317() + 2.0, entity.method_23318() + 2.0, entity.method_23321() + 2.0);
		}

		boolean visible = culler.method_23093(baseBox);
		if (!visible && culler instanceof FrustumIntersectionAccess fia) {
			// Zero-allocation inflated check: avoid AABB.inflate() by passing coordinates directly to JOML
			final org.joml.FrustumIntersection intersection = fia.lomka$getIntersection();
			if (intersection != null) {
				visible = intersection.intersectAab(
					(float)(baseBox.field_1323 - 0.5 - camX),
					(float)(baseBox.field_1322 - 0.5 - camY),
					(float)(baseBox.field_1321 - 0.5 - camZ),
					(float)(baseBox.field_1320 + 0.5 - camX),
					(float)(baseBox.field_1325 + 0.5 - camY),
					(float)(baseBox.field_1324 + 0.5 - camZ)
				) != 0;
			}
		}

		if (visible) {
			lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, true);
		} else {
			if (!(entity instanceof class_9817 l) || l.method_60952() == null) {
				lomka$recordFrustumDecision(accessor, tick, camHash15, motionHash, false);
				cir.setReturnValue(Boolean.FALSE);
			}
		}
	}

	@Unique
	private static void lomka$recordFrustumDecision(final EntityCullingAccessor accessor, final int tick, final int camHash15, final int motionHash, final boolean visible) {
		accessor.lomka$setLastRenderTick(tick);
		accessor.lomka$setLastRenderCamHash(camHash15);
		accessor.lomka$setLastRenderMotionHash(motionHash);
		accessor.lomka$setRenderVisible(visible);
	}

	@Unique
	private static int lomka$adjustIntervalByType(final class_1297 entity, final int interval) {
		if (interval <= 1) {
			return interval;
		}

		double mult = 1.0;
		if (entity instanceof class_8113) {
			mult = LOMKA$FRUSTUM_HYSTERESIS_DISPLAY_MULTIPLIER;
		} else if (entity instanceof class_1531 || entity instanceof class_1533 || entity instanceof class_1534) {
			mult = LOMKA$FRUSTUM_HYSTERESIS_STATIC_MULTIPLIER;
		} else if (entity instanceof class_1676) {
			mult = LOMKA$FRUSTUM_HYSTERESIS_PROJECTILE_MULTIPLIER;
		} else if (entity instanceof class_10255 || entity instanceof class_1688) {
			mult = LOMKA$FRUSTUM_HYSTERESIS_VEHICLE_MULTIPLIER;
		} else if (entity instanceof class_1309) {
			mult = LOMKA$FRUSTUM_HYSTERESIS_LIVING_MULTIPLIER;
		}

		if (mult == 1.0) {
			return interval;
		}

		int scaled = (int)Math.round((double)interval * mult);
		if (scaled < 1) {
			return 1;
		}
		return scaled;
	}

	@Unique
	private static int lomka$computeMotionHash(final class_1297 entity) {
		// Quantize to 0.5 blocks to increase hysteresis hit rate for slow moving entities
		int qx = class_3532.method_15357(entity.method_23317() * 2.0);
		int qy = class_3532.method_15357(entity.method_23318() * 2.0);
		int qz = class_3532.method_15357(entity.method_23321() * 2.0);
		int h = 1;
		h = 31 * h + qx;
		h = 31 * h + qy;
		h = 31 * h + qz;

		boolean isVehicle = entity instanceof class_10255 || entity instanceof class_1688;
		boolean includeRot = entity instanceof class_1309 || isVehicle;
		boolean includeVel = entity instanceof class_1676 || isVehicle;
		if (includeRot) {
			int yawQ = class_3532.method_15375((class_3532.method_15393(entity.method_36454()) + 180.0F) * 2.0F);
			int pitchQ = class_3532.method_15375((class_3532.method_15363(entity.method_36455(), -90.0F, 90.0F) + 90.0F) * 2.0F);
			h = 31 * h + yawQ;
			h = 31 * h + pitchQ;
		}
		if (includeVel) {
			class_243 v = entity.method_18798();
			int vx = class_3532.method_15357(v.field_1352 * 20.0);
			int vy = class_3532.method_15357(v.field_1351 * 20.0);
			int vz = class_3532.method_15357(v.field_1350 * 20.0);
			h = 31 * h + vx;
			h = 31 * h + vy;
			h = 31 * h + vz;
		}

		return h;
	}
}
