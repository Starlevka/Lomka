package set.starl.injection.mixins.cull;

import net.minecraft.class_2350;
import net.minecraft.class_2397;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import set.starl.Lomka;

@Mixin(class_2397.class)
public class SmartLeavesCullingMixin {
	@Inject(method = "skipRendering", at = @At("HEAD"), cancellable = true)
	private void lomka$smartCull(class_2680 state, class_2680 neighbor, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
		if (Lomka.CONFIG.culling.smartLeavesCulling) {
			if (neighbor.method_26204() instanceof class_2397) {
				if (state.method_28498(class_2741.field_12508)
					&& neighbor.method_28498(class_2741.field_12508)
					&& state.method_11654(class_2741.field_12508) != neighbor.method_11654(class_2741.field_12508)) {
					return;
				}
				cir.setReturnValue(true);
			}
		}
	}
}
