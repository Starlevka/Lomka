package set.starl.injection.mixins.cull;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_4076;
import net.minecraft.class_5562;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import set.starl.Lomka;
import set.starl.util.SectionVisibilityCache;

@Mixin(class_1937.class)
public class LevelBlockEntityTickCullMixin {
	@Unique
	private static final boolean LOMKA$ENABLE = Lomka.CONFIG.entities.enable && Lomka.CONFIG.entities.clientTickCull.enable;

	@Unique
	private static final double LOMKA$MIN_DIST_SQ = Lomka.CONFIG.entities.clientTickCull.minDistance * Lomka.CONFIG.entities.clientTickCull.minDistance;

	@Unique
	private static final boolean LOMKA$SECTION_OCCLUSION_CULL = Lomka.CONFIG.entities.sectionOcclusionCull;

	@Unique
	private static int LOMKA$LAST_LEVEL_ID = Integer.MIN_VALUE;

	@Redirect(
		method = "tickBlockEntities",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/level/block/entity/TickingBlockEntity;tick()V"
		)
	)
	private void lomka$maybeTickBlockEntity(final class_5562 ticker) {
		class_1937 level = (class_1937)(Object)this;
		if (!LOMKA$ENABLE || !LOMKA$SECTION_OCCLUSION_CULL || !level.method_8608()) {
			ticker.method_31703();
			return;
		}
		int levelId = System.identityHashCode(level);
		if (levelId != LOMKA$LAST_LEVEL_ID) {
			LOMKA$LAST_LEVEL_ID = levelId;
		}
		SectionVisibilityCache.checkLevelChange(levelId);
		if (!SectionVisibilityCache.ensureCameraCache(level.method_75260())) {
			ticker.method_31703();
			return;
		}
		class_2338 pos = ticker.method_31705();
		if (pos == null) {
			ticker.method_31703();
			return;
		}
		if (lomka$shouldTickBlockEntity(pos)) {
			ticker.method_31703();
		}
	}

	@Unique
	private static boolean lomka$shouldTickBlockEntity(final class_2338 pos) {
		double minDistSq = LOMKA$MIN_DIST_SQ;
		if (minDistSq > 0.0) {
			double px = (double)pos.method_10263() + 0.5;
			double py = (double)pos.method_10264() + 0.5;
			double pz = (double)pos.method_10260() + 0.5;
			double dx = px - SectionVisibilityCache.getCamX();
			double dy = py - SectionVisibilityCache.getCamY();
			double dz = pz - SectionVisibilityCache.getCamZ();
			if ((dx * dx + dy * dy + dz * dz) < minDistSq) {
				return true;
			}
		}
		long cellKey = class_4076.method_18685(pos.method_10263() >> 4, pos.method_10264() >> 4, pos.method_10260() >> 4);
		return SectionVisibilityCache.isSectionVisible(cellKey);
	}
}
