package set.starl.injection.access;

import net.minecraft.class_11954;
import net.minecraft.class_2586;
import org.jspecify.annotations.Nullable;

public interface BlockEntityRenderDispatcherAccessor {
	@Nullable class_11954 lomka$tryExtractRenderState(class_2586 blockEntity, float partialTicks, class_11683.@Nullable class_11792 breakProgress);
}
