package set.starl.injection.mixins.accessors;

import net.minecraft.class_11954;
import net.minecraft.class_2586;
import net.minecraft.class_824;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import set.starl.injection.access.BlockEntityRenderDispatcherAccessor;

@Mixin(class_824.class)
public abstract class BlockEntityRenderDispatcherMixin implements BlockEntityRenderDispatcherAccessor {
	@Shadow
	public abstract @Nullable class_11954 tryExtractRenderState(class_2586 blockEntity, float partialTicks, class_11683.@Nullable class_11792 breakProgress);

	@Override
	public @Nullable class_11954 lomka$tryExtractRenderState(class_2586 blockEntity, float partialTicks, class_11683.@Nullable class_11792 breakProgress) {
		return this.tryExtractRenderState(blockEntity, partialTicks, breakProgress);
	}
}
