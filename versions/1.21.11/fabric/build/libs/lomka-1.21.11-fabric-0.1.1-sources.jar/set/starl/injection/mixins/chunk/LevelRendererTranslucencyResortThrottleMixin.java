package set.starl.injection.mixins.chunk;

import set.starl.Lomka;
import net.minecraft.class_156;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class LevelRendererTranslucencyResortThrottleMixin {
	@Unique
	private static final boolean LOMKA$ENABLE = Lomka.CONFIG.render.translucencyResortThrottle;

	@Unique
	private static final long LOMKA$MAX_SKIP_MS = 100L;

	@Unique
	private static final double LOMKA$MIN_MOVE = 0.03125;

	@Unique
	private long lomka$lastRunMs;

	@Unique
	private long lomka$lastBlockLong = Long.MIN_VALUE;

	@Unique
	private double lomka$lastX;

	@Unique
	private double lomka$lastY;

	@Unique
	private double lomka$lastZ;

	@Inject(method = "scheduleTranslucentSectionResort(Lnet/minecraft/world/phys/Vec3;)V", at = @At("HEAD"), cancellable = true)
	private void lomka$throttleTranslucentResort(final class_243 cameraPos, final CallbackInfo ci) {
		if (!LOMKA$ENABLE || LOMKA$MAX_SKIP_MS <= 0L) {
			return;
		}

		long now = class_156.method_658();
		if (now - this.lomka$lastRunMs >= LOMKA$MAX_SKIP_MS) {
			return;
		}

		int bx = class_3532.method_15357(cameraPos.field_1352);
		int by = class_3532.method_15357(cameraPos.field_1351);
		int bz = class_3532.method_15357(cameraPos.field_1350);
		long blockLong = class_2338.method_10064(bx, by, bz);
		if (blockLong != this.lomka$lastBlockLong) {
			// Crosses chunk/block boundary, need resort
			return;
		}

		double dx = cameraPos.field_1352 - this.lomka$lastX;
		double dy = cameraPos.field_1351 - this.lomka$lastY;
		double dz = cameraPos.field_1350 - this.lomka$lastZ;
		double minMoveSq = LOMKA$MIN_MOVE * LOMKA$MIN_MOVE;
		if (dx * dx + dy * dy + dz * dz < minMoveSq) {
			// Sub-block movement and haven't passed skip threshold yet
			ci.cancel();
		}
	}

	@Inject(method = "scheduleTranslucentSectionResort(Lnet/minecraft/world/phys/Vec3;)V", at = @At("RETURN"))
	private void lomka$rememberResortState(final class_243 cameraPos, final CallbackInfo ci) {
		this.lomka$lastRunMs = class_156.method_658();
		this.lomka$lastX = cameraPos.field_1352;
		this.lomka$lastY = cameraPos.field_1351;
		this.lomka$lastZ = cameraPos.field_1350;
		int bx = class_3532.method_15357(cameraPos.field_1352);
		int by = class_3532.method_15357(cameraPos.field_1351);
		int bz = class_3532.method_15357(cameraPos.field_1350);
		this.lomka$lastBlockLong = class_2338.method_10064(bx, by, bz);
	}
}
