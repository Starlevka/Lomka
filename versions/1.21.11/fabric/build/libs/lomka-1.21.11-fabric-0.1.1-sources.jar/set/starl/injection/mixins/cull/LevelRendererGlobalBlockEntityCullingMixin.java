package set.starl.injection.mixins.cull;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import set.starl.injection.access.LevelRendererAccess;

import java.util.Iterator;
import java.util.SortedSet;
import net.minecraft.class_11658;
import net.minecraft.class_11683;
import net.minecraft.class_11954;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_3191;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_638;
import net.minecraft.class_761;
import net.minecraft.class_824;
import net.minecraft.class_9779;

@Mixin(class_761.class)
public abstract class LevelRendererGlobalBlockEntityCullingMixin {
	@Shadow
	@Final
	private class_824 blockEntityRenderDispatcher;

	@Shadow
	@Nullable
	private class_638 level;

	@Unique
	private static final boolean LOMKA$CULL_GLOBAL_BLOCK_ENTITIES = set.starl.Lomka.CONFIG.culling.enable && set.starl.Lomka.CONFIG.culling.cullGlobalBlockEntities;

	@Unique
	private static final ThreadLocal<class_4604> LOMKA$CAPTURED_FRUSTUM = new ThreadLocal<>();

	@Inject(
		method = "extractVisibleEntities",
		at = @At("HEAD")
	)
	private void lomka$captureFrustum(class_4184 camera, class_4604 frustum, class_9779 deltaTracker, class_11658 levelRenderState, CallbackInfo ci) {
		if (LOMKA$CULL_GLOBAL_BLOCK_ENTITIES) {
			LOMKA$CAPTURED_FRUSTUM.set(frustum);
		}
	}

	@Inject(
		method = "extractVisibleBlockEntities",
		at = @At("HEAD"),
		cancellable = true
	)
	private void lomka$cullGlobalBlockEntities(class_4184 camera, float deltaPartialTick, class_11658 levelRenderState, CallbackInfo ci) {
		if (!LOMKA$CULL_GLOBAL_BLOCK_ENTITIES || this.level == null) {
			return;
		}

		class_4604 frustum = LOMKA$CAPTURED_FRUSTUM.get();
		if (frustum == null) {
			return;
		}

		ci.cancel();

		class_243 cameraPos = camera.method_71156();
		double camX = cameraPos.method_10216();
		double camY = cameraPos.method_10214();
		double camZ = cameraPos.method_10215();
		class_4587 poseStack = new class_4587();

		LevelRendererAccess access = (LevelRendererAccess) this;
		Long2ObjectMap<SortedSet<class_3191>> destructionProgress = access.lomka$getDestructionProgress();
		Iterator<?> iterator = access.lomka$getVisibleSections().iterator();

		while (iterator.hasNext()) {
			net.minecraft.class_846.class_851 section = (net.minecraft.class_846.class_851) iterator.next();
			java.util.List<class_2586> renderableBlockEntities = section.method_72052().method_72033();
			if (!renderableBlockEntities.isEmpty() && !(section.method_76298(net.minecraft.class_156.method_658()) < 0.3F)) {
				for (class_2586 be : renderableBlockEntities) {
					net.minecraft.class_827<?, ?> renderer = this.blockEntityRenderDispatcher.method_3550(be);
					if (renderer == null || renderer.method_3563() || frustum.method_23093(new class_238(be.method_11016()))) {
						this.lomka$extractBE(be, deltaPartialTick, levelRenderState, destructionProgress, poseStack, camX, camY, camZ);
					}
				}
			}
		}

		LOMKA$CAPTURED_FRUSTUM.remove();
	}

	@Unique
	private void lomka$extractBE(class_2586 be, float delta, class_11658 state, Long2ObjectMap<SortedSet<class_3191>> destructionProgress, class_4587 poseStack, double camX, double camY, double camZ) {
		class_2338 pos = be.method_11016();
		SortedSet<class_3191> progresses = destructionProgress.get(pos.method_10063());
		class_11683.class_11792 breakProgress;
		if (progresses != null && !progresses.isEmpty()) {
			poseStack.method_22903();
			poseStack.method_22904((double)pos.method_10263() - camX, (double)pos.method_10264() - camY, (double)pos.method_10260() - camZ);
			breakProgress = new class_11683.class_11792(((class_3191)progresses.last()).method_13988(), poseStack.method_23760());
			poseStack.method_22909();
		} else {
			breakProgress = null;
		}

		class_11954 beState = this.blockEntityRenderDispatcher.method_74348(be, delta, breakProgress);
		if (beState != null) {
			state.field_62646.add(beState);
		}
	}
}
