package set.starl.injection.mixins.network;

import io.netty.buffer.ByteBuf;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.concurrent.Semaphore;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import set.starl.Lomka;

@Mixin(class_2540.class)
public class FriendlyByteBufNbtCodecThrottleMixin {
	@Unique
	private static final int LOMKA$PARALLELISM = Lomka.CONFIG.nbt.codecParallelism;

	@Unique
	private static final Semaphore LOMKA$GUARD = LOMKA$PARALLELISM > 0 ? new Semaphore(Math.min(64, Math.max(1, LOMKA$PARALLELISM))) : null;

	@Redirect(
		method = "readNbt(Lio/netty/buffer/ByteBuf;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag;",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/nbt/NbtIo;readAnyTag(Ljava/io/DataInput;Lnet/minecraft/nbt/NbtAccounter;)Lnet/minecraft/nbt/Tag;"
		)
	)
	private static class_2520 lomka$readAnyTagThrottled(final DataInput input, final class_2505 accounter) throws IOException {
		Semaphore guard = LOMKA$GUARD;
		if (guard == null) {
			return class_2507.method_52894(input, accounter);
		}

		guard.acquireUninterruptibly();
		try {
			return class_2507.method_52894(input, accounter);
		} finally {
			guard.release();
		}
	}

	@Redirect(
		method = "writeNbt(Lio/netty/buffer/ByteBuf;Lnet/minecraft/nbt/Tag;)V",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/nbt/NbtIo;writeAnyTag(Lnet/minecraft/nbt/Tag;Ljava/io/DataOutput;)V"
		)
	)
	private static void lomka$writeAnyTagThrottled(final class_2520 tag, final DataOutput output) throws IOException {
		Semaphore guard = LOMKA$GUARD;
		if (guard == null) {
			class_2507.method_52893(tag, output);
			return;
		}

		guard.acquireUninterruptibly();
		try {
			class_2507.method_52893(tag, output);
		} finally {
			guard.release();
		}
	}
}
