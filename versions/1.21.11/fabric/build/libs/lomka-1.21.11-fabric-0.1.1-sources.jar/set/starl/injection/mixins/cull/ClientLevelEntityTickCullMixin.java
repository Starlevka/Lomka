package set.starl.injection.mixins.cull;

import it.unimi.dsi.fastutil.ints.Int2LongOpenHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_1531;
import net.minecraft.class_1533;
import net.minecraft.class_1534;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4076;
import net.minecraft.class_638;
import net.minecraft.class_8113;
import set.starl.Lomka;
import set.starl.util.SectionVisibilityCache;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public class ClientLevelEntityTickCullMixin {
	@Unique
	private static final boolean LOMKA$ENABLE = Lomka.CONFIG.entities.enable && Lomka.CONFIG.entities.clientTickCull.enable;

	@Unique
	private static final double LOMKA$MIN_DISTANCE = Lomka.CONFIG.entities.clientTickCull.minDistance;

	@Unique
	private static final double LOMKA$MIN_DIST_SQ = LOMKA$MIN_DISTANCE <= 0.0 ? -1.0 : LOMKA$MIN_DISTANCE * LOMKA$MIN_DISTANCE;

	@Unique
	private static final int LOMKA$MIN_CHUNK_DISTANCE = 4;

	@Unique
	private static final int LOMKA$INTERVAL_TICKS = 20;

	@Unique
	private static final long LOMKA$INTERVAL_L = (long)LOMKA$INTERVAL_TICKS;

	@Unique
	private static final boolean LOMKA$INTERVAL_POW2 = LOMKA$INTERVAL_TICKS > 0 && (LOMKA$INTERVAL_TICKS & (LOMKA$INTERVAL_TICKS - 1)) == 0;

	@Unique
	private static final long LOMKA$INTERVAL_MASK = LOMKA$INTERVAL_POW2 ? (LOMKA$INTERVAL_L - 1L) : 0L;

	@Unique
	private static final int LOMKA$WARMUP_TICKS = 5;

	@Unique
	private static final int LOMKA$MOTION_SAMPLE_TICKS = 10;

	@Unique
	private static final boolean LOMKA$INCLUDE_DISPLAY = false;

	@Unique
	private static final boolean LOMKA$SECTION_OCCLUSION_CULL = Lomka.CONFIG.entities.sectionOcclusionCull;

	@Unique
	private static final Int2LongOpenHashMap LOMKA$MOTION_SAMPLE_BY_ID = new Int2LongOpenHashMap(512);

	@Unique
	private static int LOMKA$LAST_LEVEL_ID = Integer.MIN_VALUE;

	static {
		LOMKA$MOTION_SAMPLE_BY_ID.defaultReturnValue(Long.MIN_VALUE);
	}

	@Shadow
	@Final
	private class_310 minecraft;

	@Inject(method = "tickNonPassenger", at = @At("HEAD"), cancellable = true)
	private void lomka$throttleTickNonPassenger(final class_1297 entity, final CallbackInfo ci) {
		if (!LOMKA$ENABLE) {
			return;
		}

		if (LOMKA$MIN_DIST_SQ <= 0.0) {
			return;
		}

		if (LOMKA$INTERVAL_TICKS <= 1) {
			return;
		}

		if (!lomka$isCandidate(entity)) {
			return;
		}

		class_638 level = (class_638)(Object)this;
		int levelId = System.identityHashCode(level);
		if (levelId != LOMKA$LAST_LEVEL_ID) {
			LOMKA$LAST_LEVEL_ID = levelId;
			LOMKA$MOTION_SAMPLE_BY_ID.clear();
		}
		SectionVisibilityCache.checkLevelChange(levelId);

		int warmup = LOMKA$WARMUP_TICKS;
		if (warmup > 0 && entity.field_6012 < warmup) {
			return;
		}

		if (!entity.method_5685().isEmpty()) {
			return;
		}

		int motionSampleTicks = LOMKA$MOTION_SAMPLE_TICKS;
		if (motionSampleTicks > 0) {
			Int2LongOpenHashMap m = LOMKA$MOTION_SAMPLE_BY_ID;
			long packed = m.get(entity.method_5628());
			int lastSampleTick = (int)packed;
			boolean lastStatic = ((packed >>> 32) & 1L) != 0L;
			int now = entity.field_6012;
			if (lastSampleTick == Integer.MIN_VALUE || now - lastSampleTick >= motionSampleTicks) {
				class_243 v = entity.method_18798();
				lastStatic = (v.field_1352 * v.field_1352 + v.field_1351 * v.field_1351 + v.field_1350 * v.field_1350) <= 1.0E-8;
				// Prevent unbounded growth
				if (m.size() < 4096) {
					m.put(entity.method_5628(), ((long)now) | (lastStatic ? (1L << 32) : 0L));
				} else {
					// Clear oldest entries when limit reached
					m.clear();
					m.put(entity.method_5628(), ((long)now) | (lastStatic ? (1L << 32) : 0L));
				}
			}
			if (!lastStatic) return;
		}

		long gameTime = level.method_75260();

		if (!SectionVisibilityCache.ensureCameraCache(gameTime)) {
			return;
		}

		int minChunk = LOMKA$MIN_CHUNK_DISTANCE;
		double dist2 = -1.0;
		if (minChunk > 0) {
			int ex = entity.method_24515().method_10263() >> 4;
			int ez = entity.method_24515().method_10260() >> 4;
			int dx = ex - SectionVisibilityCache.getCamChunkX();
			int dz = ez - SectionVisibilityCache.getCamChunkZ();
			if (dx < 0) {
				dx = -dx;
			}
			if (dz < 0) {
				dz = -dz;
			}
			if (dx < minChunk && dz < minChunk) {
				double ddx = entity.method_23317() - SectionVisibilityCache.getCamX();
				double ddy = entity.method_23318() - SectionVisibilityCache.getCamY();
				double ddz = entity.method_23321() - SectionVisibilityCache.getCamZ();
				dist2 = ddx * ddx + ddy * ddy + ddz * ddz;
				if (dist2 < LOMKA$MIN_DIST_SQ) {
					return;
				}
			}
		} else {
			double ddx = entity.method_23317() - SectionVisibilityCache.getCamX();
			double ddy = entity.method_23318() - SectionVisibilityCache.getCamY();
			double ddz = entity.method_23321() - SectionVisibilityCache.getCamZ();
			dist2 = ddx * ddx + ddy * ddy + ddz * ddz;
			if (dist2 < LOMKA$MIN_DIST_SQ) {
				return;
			}
		}

		if (LOMKA$SECTION_OCCLUSION_CULL && !(entity instanceof class_1657)) {
			double minDistSq = LOMKA$MIN_DIST_SQ;
			if (minDistSq <= 0.0 || dist2 >= minDistSq) {
				int ex = class_3532.method_15357(entity.method_23317());
				int ey = class_3532.method_15357(entity.method_23318());
				int ez = class_3532.method_15357(entity.method_23321());
				long cellKey = class_4076.method_18685(ex >> 4, ey >> 4, ez >> 4);
				if (!SectionVisibilityCache.isSectionVisible(cellKey)) {
					entity.method_22862();
					++entity.field_6012;
					ci.cancel();
					return;
				}
			}
		}

		int id = entity.method_5628();
		long phase = gameTime + (long)id;
		boolean shouldFullTick = LOMKA$INTERVAL_POW2
			? (phase & LOMKA$INTERVAL_MASK) == 0L
			: (phase % LOMKA$INTERVAL_L) == 0L;
		if (!shouldFullTick) {
			entity.method_22862();
			++entity.field_6012;
			ci.cancel();
			return;
		}
	}

	@Unique
	private static boolean lomka$isCandidate(final class_1297 entity) {
		return (LOMKA$INCLUDE_DISPLAY && entity instanceof class_8113)
			|| entity instanceof class_1531
			|| entity instanceof class_1533
			|| entity instanceof class_1534;
	}
}
