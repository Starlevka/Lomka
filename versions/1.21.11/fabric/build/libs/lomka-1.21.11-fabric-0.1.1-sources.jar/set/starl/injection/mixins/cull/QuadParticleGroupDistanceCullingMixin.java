package set.starl.injection.mixins.cull;

import java.util.Objects;
import net.minecraft.class_11938;
import net.minecraft.class_11940;
import net.minecraft.class_11942;
import net.minecraft.class_11944;
import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_148;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3940;
import net.minecraft.class_3999;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_11940.class)
public class QuadParticleGroupDistanceCullingMixin {
	@Shadow
	@Final
	class_11944 particleTypeRenderState;

	@Shadow
	@Final
	private class_3999 particleType;

	@Unique
	private static final double LOMKA$MAX_DISTANCE = set.starl.Lomka.CONFIG.particles.maxDistance;

	@Unique
	private static final double LOMKA$MAX_DIST_SQ = LOMKA$MAX_DISTANCE <= 0.0 ? -1.0 : LOMKA$MAX_DISTANCE * LOMKA$MAX_DISTANCE;

	@Unique
	private static final int LOMKA$MIN_COUNT = 128;

	@Inject(method = "extractRenderState", at = @At("HEAD"), cancellable = true)
	private void lomka$extractRenderStateCulled(final class_4604 frustum, final class_4184 camera, final float partialTickTime, final CallbackInfoReturnable<class_11942> cir) {
		if (LOMKA$MAX_DIST_SQ <= 0.0 && ((class_11938)(Object)this).method_74289() < LOMKA$MIN_COUNT) {
			return;
		}

		this.particleTypeRenderState.method_74316();

		double maxDistSq = LOMKA$MAX_DIST_SQ;
		class_243 cam = camera.method_71156();
		double camX = cam.method_10216();
		double camY = cam.method_10214();
		double camZ = cam.method_10215();

		for (Object o : ((class_11938)(Object)this).method_74290()) {
			class_3940 particle = (class_3940)o;
			class_238 bb = particle.method_3064();
			if (bb.method_1013()) {
				continue;
			}
			class_238 cullBox = bb.method_995() == 0.0 ? bb.method_1014(0.25) : bb;
			if (!frustum.method_23093(cullBox)) {
				continue;
			}
			if (maxDistSq > 0.0) {
				double cx = (bb.field_1323 + bb.field_1320) * 0.5;
				double cy = (bb.field_1322 + bb.field_1325) * 0.5;
				double cz = (bb.field_1321 + bb.field_1324) * 0.5;
				double dx = cx - camX;
				double dy = cy - camY;
				double dz = cz - camZ;
				if (dx * dx + dy * dy + dz * dz > maxDistSq) {
					continue;
				}
			}

			try {
				particle.method_3074(this.particleTypeRenderState, camera, partialTickTime);
			} catch (Throwable t) {
				class_128 report = class_128.method_560(t, "Rendering Particle");
				class_129 category = report.method_562("Particle being rendered");
				Objects.requireNonNull(particle);
				category.method_577("Particle", particle::toString);
				class_3999 var10002 = this.particleType;
				Objects.requireNonNull(var10002);
				category.method_577("Particle Type", var10002::toString);
				throw new class_148(report);
			}
		}

		cir.setReturnValue(this.particleTypeRenderState);
	}
}
